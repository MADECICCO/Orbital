pass # dummy to make visual_common a package
