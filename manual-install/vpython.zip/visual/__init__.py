from __future__ import print_function

from visual.visual_all import * # this statement not included in vis/__init__.py
from visual_common.create_display import *

scene = display()
