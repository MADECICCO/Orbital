
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.3'
version = '1.11.3'
full_version = '1.11.3'
git_revision = 'b0a52b76c2bebe5c237722589d13bf02affa9c43'
release = True

if not release:
    version = full_version
